hytopo
======

hytopo is a molecular dynamics trajectory analysis tool for gas hydrate systems.
It performs hydrate order-parameter classification, hydrate cage detection,
guest-centered cage tracking, nucleation analysis, cage transition pathway
network generation, and final summary reporting.

hytopo is designed for trajectories readable by MDAnalysis, such as GROMACS
.tpr/.xtc/.trr/.gro/.pdb files.


Main Features
=============

1. Hydrate order-parameter analysis
   - Classifies water molecules into liquid-like, ice-like, hydrate-like,
     hydrate precursor, and uncertain/interface states.
   - Outputs hydrate_timeseries.dat and hydrate_labels.dat.
   - Can write a HOP-labeled PDB trajectory for visualization.

2. Cage detection
   - Detects guest-centered hydrate cages from local water oxygen networks.
   - Supports standard cages, partial cages, half cages, open cages,
     distorted cages, incipient cages, and selected non-standard cages.
   - Outputs cage statistics and per-frame cage PDB files.

3. Cage tracking
   - Tracks the same cage around the same guest molecule over time.
   - Reports cage lifetime, cage type transitions, and guest occupancy.
   - Outputs cage_lifetime.dat, cage_transitions.dat, and cage_occupancy.dat.

4. Nucleation analysis
   - Uses Nmax_hyd from hydrate_timeseries.dat.
   - Detects hydrate nucleation when the largest hydrate-like cluster exceeds
     a threshold and persists for a specified number of analyzed frames.
   - Outputs nucleation_summary.txt and nucleation_timeseries.dat.

5. Cage transition pathway network
   - Converts cage transition events into a directed weighted network.
   - Useful for visualizing pathways such as:
       Liquid -> half_5^12 -> 5^12 -> 5^12_6^2
   - Outputs cage_transition_network.png.

6. Final summary report
   - Generates a one-click global report of the simulation.
   - Summarizes nucleation, cage lifetimes, cage diversity, guest occupancy,
     and kinetic trends.
   - Outputs final_summary.txt.


Requirements
============

Required Python packages:

  Python >= 3.10
  numpy
  scipy
  MDAnalysis
  numba
  matplotlib
  networkx

Recommended installation through conda:

  conda create -n hytopo python=3.11
  conda activate hytopo
  conda install -c conda-forge numpy scipy mdanalysis numba matplotlib networkx

If hytopo is packaged with pyproject.toml, install it from the project root:

  pip install .

After installation, the command-line program should be available as:

  hytopo -h   

If not installed as a package, run it as a Python module from the project root:

  python -m hytopo.cli -h


Basic Usage
===========

Typical command:

  python -m hytopo.cli \
    -top test.tpr \
    -traj test.xtc \
    -start 0 \
    -stop 10001 \
    -stride 2 \
    -guest "resname CH4" \
    --find-cages \
    --hop-pdb-stride 1000 \
    --cage-pdb-stride 1000

If installed as a console command:

  hytopo \
    -top test.tpr \
    -traj test.xtc \
    -start 0 \
    -stop 10001 \
    -stride 2 \
    -guest "resname CH4" \
    --find-cages \
    --hop-pdb-stride 1000 \
    --cage-pdb-stride 1000


Input Options
=============

Required:

  -top, --top
      Topology or structure file.
      Examples: npt.tpr, system.gro, system.pdb

Optional:

  -traj, --traj
      Trajectory file.
      Examples: traj.xtc, traj.trr
      If omitted, only the topology/structure is loaded.

  -water, --water-selection
      Water molecule selection.
      Default: resname SOL

  -oxygen, --oxygen-selection
      Water oxygen atom selection.
      Default: name OW

  -guest, --guest-selection
      Guest atom or molecule selection for cage analysis.
      Example: "resname CH4"

Frame control:

  -start, --start
      First frame index.
      Default: 0

  -stop, --stop
      Stop frame index, exclusive.
      Default: None

  -stride, --stride
      Frame stride.
      Default: 1


Analysis Mode Options
=====================

  --find-cages
      Enable cage detection after HOP classification.

  --skip-hop
      Skip HOP analysis.
      Current runner normally requires HOP analysis, so this option is mainly
      for debugging and should not be used for normal hydrate analysis.

  --no-exclude-liquid
      Do not exclude liquid-like water molecules from cage detection.

  --include-ice-for-cage
      Allow ice-like water molecules to participate in cage detection.

  --standard-cages-only
      Only report complete standard cages and disable partial cage fallback.


Important HOP Parameters
========================

  --oo-cutoff
      O-O cutoff for HOP neighbor graph.
      Default: 3.5

  --dist-smooth
      Distance smoothing width for HOP coordination.
      Default: 0.15

  --pc-hyd
      Probability threshold for hydrate classification.
      Default: 0.50

  --pc-ice
      Probability threshold for ice classification.
      Default: 0.50


Important Cage Parameters
=========================

  --cage-oo-cutoff
      O-O cutoff for cage ring graph.
      Default: 3.6

  --guest-radius
      Radius for selecting local water molecules around each guest.
      Default: 6.2

  --face-radius
      Maximum guest-ring center distance.
      Default: 7.2

  --min-ring
      Minimum ring size considered in cage detection.
      Default: 4

  --max-ring
      Maximum ring size considered in cage detection.
      Default: 6

  --max-local-cycles
      Maximum number of local cycles enumerated per guest.
      Default: 5000

  --max-rings-per-guest
      Maximum scored rings kept for each guest.
      Default: 56

  --ring-backend
      Ring enumeration backend.
      Choices: auto, python, numba, cpp
      Default: auto


Nucleation Options
==================

hytopo detects nucleation using Nmax_hyd from hydrate_timeseries.dat.

Default criterion:

  Nmax_hyd >= 50
  and the condition persists for 10 analyzed frames.

Options:

  --no-nucleation
      Disable nucleation analysis.

  --nucleation-min-size
      Minimum Nmax_hyd required for nucleation.
      Default: 50

  --nucleation-persist-frames
      Number of consecutive analyzed frames required.
      Default: 10

  --nucleation-allow-gaps
      Allowed below-threshold frames inside a persistent nucleation window.
      Default: 0

Example:

  hytopo \
    -top test.tpr \
    -traj test.xtc \
    -guest "resname CH4" \
    --find-cages \
    --nucleation-min-size 100 \
    --nucleation-persist-frames 20 \
    --nucleation-allow-gaps 2


Output Options
==============

  -outdir, --outdir
      Output directory.
      Default: hydrate_analysis

  --timeseries
      HOP/cage time-series output filename.
      Default: hydrate_timeseries.dat

  --labels
      Per-water HOP label output filename.
      Default: hydrate_labels.dat

  --no-labels
      Disable per-water text label output.

  --label-stride
      Frame interval for label output.
      Default: 100

  --hop-pdb
      HOP-labeled PDB trajectory filename.
      Default: hydrate_labels.pdb

  --no-hop-pdb
      Disable HOP PDB output.

  --hop-pdb-stride
      Frame interval for HOP PDB MODEL output.
      Default: 1

  --cage-stat
      Cage statistics output filename.
      Default: cage_stat.dat

  --shell-stat
      Guest shell statistics output filename.
      Default: guest_shell.dat

  --cage-pdb-dir
      Directory for per-frame cage PDB files.
      Default: cage_pdb

  --no-cage-pdb
      Disable cage PDB output.

  --cage-pdb-stride
      Frame interval for cage PDB output.
      Default: 1


Output Files
============

In the output directory, hytopo may generate:

  hydrate_timeseries.dat
      Main time-series file.
      Includes HOP counts, hydrate-like water counts, Nmax_hyd, and cage counts.

  hydrate_labels.dat
      Per-water HOP labels.

  hydrate_labels.pdb
      Multi-model PDB trajectory for visualizing HOP labels.

  cage_stat.dat
      Cage count statistics per frame.

  guest_shell.dat
      Guest shell statistics.

  cage_pdb/
      Per-frame cage visualization PDB files.

  cage_lifetime.dat
      Lifetime information for tracked cages.

  cage_transitions.dat
      Cage type transition events.

  cage_occupancy.dat
      Guest occupancy information for cages.

  nucleation_summary.txt
      Summary of nucleation detection.

  nucleation_timeseries.dat
      Per-frame nucleation status based on Nmax_hyd.

  cage_transition_network.png
      Directed weighted cage transition pathway network.

  hydrate_timeseries.png
      Plot of the main hydrate time series.

  cage_counts.png
      Plot of cage counts.

  final_summary.txt
      One-click global analysis report.


Interpreting Key Results
========================

Nmax_hyd:

  Nmax_hyd is the size of the largest hydrate-like water cluster.
  It is used for nucleation analysis.

Nucleation time:

  The nucleation frame is the first frame of a persistent interval where:

    Nmax_hyd >= nucleation_min_size

  for at least nucleation_persist_frames analyzed frames.

Cage lifetime:

  A cage lifetime is the time interval between the first and last detection of
  the same tracked cage around the same guest molecule.

  Average cage lifetime:
      Mean lifetime of all tracked cages whose dominant type is the listed type.

  Maximum cage lifetime:
      Longest lifetime observed among cages of that dominant type.

  A lifetime of 0 ps usually means the cage was detected only in a single
  analyzed frame.

Cage transition network:

  Nodes are cage states, such as Liquid, half_5^12, 5^12, 5^12_6^2, etc.

  Directed edges are observed transitions.

  Edge weights or labels represent how frequently the transition occurred.
  Depending on network.py settings, labels may be shown as raw counts or
  transition rates.

Guest occupancy:

  Guest occupancy statistics classify cages as empty, single-guest, or
  multiple-guest states. Multiple occupancy may indicate high pressure,
  unusual cage sharing, or an overly broad guest selection.


Typical Workflows
=================

1. HOP-only analysis:

  hytopo \
    -top test.tpr \
    -traj test.xtc \
    -start 0 \
    -stop 10001 \
    -stride 2

2. HOP plus cage analysis:

  hytopo \
    -top test.tpr \
    -traj test.xtc \
    -start 0 \
    -stop 10001 \
    -stride 2 \
    -guest "resname CH4" \
    --find-cages

3. Faster test run:

  hytopo \
    -top test.tpr \
    -traj test.xtc \
    -start 0 \
    -stop 100 \
    -stride 5 \
    -guest "resname CH4" \
    --find-cages \
    --hop-pdb-stride 50 \
    --cage-pdb-stride 50

4. Full production run with sparse visualization output:

  hytopo \
    -top test.tpr \
    -traj test.xtc \
    -start 0 \
    -stop 10001 \
    -stride 2 \
    -guest "resname CH4" \
    --find-cages \
    --hop-pdb-stride 1000 \
    --cage-pdb-stride 1000


Performance Notes
=================

1. Cage detection is more expensive than HOP classification.
   For large systems, start with a short test trajectory.

2. Increase --stride for fast screening.
   For final quantitative analysis, use a stride appropriate for the time
   resolution needed in lifetime and transition statistics.

3. --hop-pdb-stride and --cage-pdb-stride only control visualization output.
   They do not change the actual analysis stride.

4. If numba causes problems on a system, try:

  --no-numba

5. If multiprocessing causes problems, try:

  --serial


Troubleshooting
===============

1. ModuleNotFoundError: No module named 'hytopo'

   Run the command from the project root, not from inside the hytopo package
   directory. Alternatively install the package with:

     pip install .

2. MDAnalysis cannot read the trajectory

   Check that the topology and trajectory match.
   For GROMACS trajectories, .tpr + .xtc is recommended.

3. No cages found

   Check:
     - Did you use --find-cages?
     - Did you provide -guest/--guest-selection?
     - Is the guest selection correct?
     - Try relaxing cage candidate filters:
         --no-exclude-liquid
         --include-ice-for-cage
     - Check guest_shell.dat to confirm guests have nearby water molecules.

4. Cage output is empty but HOP works

   The trajectory may contain hydrate-like water clusters without well-defined
   guest-centered cages under the current geometric thresholds.
   Try adjusting:
     --guest-radius
     --face-radius
     --cage-oo-cutoff

5. Nucleation not detected even though max_Nmax_hyd is large

   Nucleation requires persistence, not just one large frame.
   Reduce:
     --nucleation-persist-frames

   or adjust:
     --nucleation-min-size

6. Network plot is too crowded

   Edit network.py control parameters, such as:
     min_edge_weight
     layout_type
     node_scale
     edge_scale

   Increasing min_edge_weight removes low-frequency noisy paths.


Citation / Reporting
====================

When reporting cage lifetimes, use a definition like:

  The lifetime of a cage track was defined as the time interval between its
  first and last detection around the same guest molecule, with continuity
  assigned based on guest identity and water-set overlap between analyzed
  frames. Average lifetimes were computed over all tracks whose dominant cage
  type matched the reported topology.

When reporting nucleation time, use a definition like:

  Hydrate nucleation was identified when the largest hydrate-like water cluster
  Nmax_hyd exceeded a threshold and persisted for a specified number of
  analyzed frames. The nucleation time was assigned to the first frame of this
  persistent interval.


License
=======

Specify the license here before distribution.
Common choices for academic software are MIT, BSD-3-Clause, or GPL-3.0.


Contact
=======

Add author name, affiliation, and contact information here.