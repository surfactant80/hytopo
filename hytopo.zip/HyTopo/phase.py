from __future__ import annotations

"""Global hydrate crystal-phase tendency from detected complete cages.

This is a composition-based phase assignment, not a full crystallographic
space-group determination.  It is useful for noisy growth/decomposition
trajectories because it reports both the best phase and a confidence score.
"""

from collections import Counter
from dataclasses import dataclass
import math
import os
from typing import Any, Optional


PHASE_UNKNOWN = "unknown"
PHASE_SI = "sI"
PHASE_SII = "sII"
PHASE_SH = "sH"
PHASE_MIXED = "mixed"


PHASE_TARGETS: dict[str, dict[str, int]] = {
    PHASE_SI: {
        "5^12": 2,
        "5^12_6^2": 6,
    },
    PHASE_SII: {
        "5^12": 16,
        "5^12_6^4": 8,
    },
    PHASE_SH: {
        "5^12": 3,
        "4^3_5^6_6^3": 2,
        "5^12_6^8": 1,
    },
}


@dataclass(frozen=True)
class PhaseParameters:
    enabled: bool = True
    min_complete_cages: int = 4
    min_confidence: float = 0.60
    transition_persist_frames: int = 3
    mixed_margin: float = 0.08


@dataclass(frozen=True)
class PhaseClassification:
    frame: int
    time_ps: float
    phase: str
    confidence: float
    scores: dict[str, float]
    n_complete_cages: int
    counts: dict[str, int]
    units_estimate: float


@dataclass(frozen=True)
class PhaseTransition:
    frame: int
    time_ps: float
    from_phase: str
    to_phase: str
    confidence: float


def classify_phase(
    frame: int,
    time_ps: float,
    cages: Any,
    params: Optional[PhaseParameters] = None,
) -> PhaseClassification:
    params = params or PhaseParameters()
    counts = Counter()

    for cage in getattr(cages, "cages", cages or []):
        cage_type = getattr(cage, "cage_type", getattr(cage, "type", ""))
        if cage_type in {
            "5^12",
            "5^12_6^2",
            "5^12_6^4",
            "4^3_5^6_6^3",
            "5^12_6^8",
        }:
            counts[str(cage_type)] += 1

    n_complete = sum(counts.values())
    if n_complete < params.min_complete_cages:
        return PhaseClassification(
            frame=int(frame),
            time_ps=float(time_ps),
            phase=PHASE_UNKNOWN,
            confidence=0.0,
            scores={phase: 0.0 for phase in PHASE_TARGETS},
            n_complete_cages=n_complete,
            counts=dict(counts),
            units_estimate=0.0,
        )

    scores: dict[str, float] = {}
    units: dict[str, float] = {}

    for phase, target in PHASE_TARGETS.items():
        target_total = float(sum(target.values()))
        observed_total = float(sum(counts.get(name, 0) for name in target))
        observed_fraction = {
            name: counts.get(name, 0) / max(observed_total, 1.0)
            for name in target
        }
        target_fraction = {
            name: value / target_total for name, value in target.items()
        }

        composition_similarity = 1.0 - 0.5 * sum(
            abs(observed_fraction[name] - target_fraction[name])
            for name in target
        )
        unit_estimate = min(
            counts.get(name, 0) / float(value)
            for name, value in target.items()
        )
        expected_from_units = unit_estimate * target_total
        coverage = min(1.0, expected_from_units / max(n_complete, 1.0))

        # Composition is more informative than absolute amount; coverage
        # prevents a tiny accidental subset from being over-interpreted.
        scores[phase] = 0.75 * composition_similarity + 0.25 * coverage
        units[phase] = unit_estimate

    ordered = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    best_phase, best_score = ordered[0]
    second_score = ordered[1][1]
    confidence = max(0.0, min(1.0, best_score - second_score + best_score * 0.5))

    if best_score < params.min_confidence or (
        best_score - second_score < params.mixed_margin
    ):
        phase = PHASE_MIXED
    else:
        phase = best_phase

    return PhaseClassification(
        frame=int(frame),
        time_ps=float(time_ps),
        phase=phase,
        confidence=float(confidence),
        scores={name: float(value) for name, value in scores.items()},
        n_complete_cages=n_complete,
        counts=dict(counts),
        units_estimate=float(units[best_phase]),
    )


class PhaseTracker:
    def __init__(self, params: Optional[PhaseParameters] = None) -> None:
        self.params = params or PhaseParameters()
        self.points: list[PhaseClassification] = []
        self.transitions: list[PhaseTransition] = []
        self._stable_phase = PHASE_UNKNOWN
        self._candidate_phase: Optional[str] = None
        self._candidate_count = 0

    def update(
        self,
        frame: int,
        time_ps: float,
        cages: Any,
    ) -> PhaseClassification:
        point = classify_phase(frame, time_ps, cages, self.params)
        self.points.append(point)

        candidate = (
            point.phase
            if point.confidence >= self.params.min_confidence
            else PHASE_UNKNOWN
        )
        if candidate == self._candidate_phase:
            self._candidate_count += 1
        else:
            self._candidate_phase = candidate
            self._candidate_count = 1

        if (
            candidate != self._stable_phase
            and self._candidate_count >= self.params.transition_persist_frames
        ):
            self.transitions.append(
                PhaseTransition(
                    frame=point.frame,
                    time_ps=point.time_ps,
                    from_phase=self._stable_phase,
                    to_phase=candidate,
                    confidence=point.confidence,
                )
            )
            self._stable_phase = candidate

        return point

    def write_outputs(self, outdir: str) -> None:
        os.makedirs(outdir, exist_ok=True)
        path = os.path.join(outdir, "hydrate_phase_timeseries.dat")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(
                "frame time_ps phase confidence n_complete_cages units_estimate "
                "sI_score sII_score sH_score n_5^12 n_5^12_6^2 "
                "n_5^12_6^4 n_4^3_5^6_6^3 n_5^12_6^8\n"
            )
            for point in self.points:
                handle.write(
                    f"{point.frame} {point.time_ps:.6f} {point.phase} "
                    f"{point.confidence:.6f} {point.n_complete_cages} "
                    f"{point.units_estimate:.6f} "
                    f"{point.scores.get(PHASE_SI, 0.0):.6f} "
                    f"{point.scores.get(PHASE_SII, 0.0):.6f} "
                    f"{point.scores.get(PHASE_SH, 0.0):.6f} "
                    f"{point.counts.get('5^12', 0)} "
                    f"{point.counts.get('5^12_6^2', 0)} "
                    f"{point.counts.get('5^12_6^4', 0)} "
                    f"{point.counts.get('4^3_5^6_6^3', 0)} "
                    f"{point.counts.get('5^12_6^8', 0)}\n"
                )

        transition_path = os.path.join(outdir, "hydrate_phase_transitions.dat")
        with open(transition_path, "w", encoding="utf-8") as handle:
            handle.write("frame time_ps from_phase to_phase confidence\n")
            for transition in self.transitions:
                handle.write(
                    f"{transition.frame} {transition.time_ps:.6f} "
                    f"{transition.from_phase} {transition.to_phase} "
                    f"{transition.confidence:.6f}\n"
                )

    @property
    def dominant_phase(self) -> str:
        if not self.points:
            return PHASE_UNKNOWN
        counts = Counter(point.phase for point in self.points)
        return counts.most_common(1)[0][0]
