from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from itertools import combinations
from typing import Optional

import numpy as np

from .config import CAGE_TYPES, TARGETS, TYPE_PRIORITY, CageParameters
from .neighbor import (
    NeighborGraph,
    build_local_graph_for_guest,
    build_local_graph_from_nodes,
    prune_local_graph_to_two_core,
    select_nodes_within_radius,
)
from .rings import (
    GuestRing,
    RingRecord,
    build_guest_rings_from_local_graph,
    estimate_directional_coverage,
)


@dataclass
class GuestShell:
    guest_id: int
    guest_center: tuple[float, float, float]
    ring_ids: tuple[int, ...]
    n4: int
    n5: int
    n6: int
    n_faces: int
    closure: float
    boundary_edges: int
    euler: int
    connected: bool
    coverage: float
    nearest_target: str
    target_distance: int
    nodes: tuple[int, ...]
    edges: tuple[tuple[int, int], ...]


@dataclass
class Cage:
    nodes: tuple[int, ...]
    edges: tuple[tuple[int, int], ...]
    rings: tuple[int, ...]
    cage_type: str
    center: tuple[float, float, float]
    guest_id: int
    frame: int
    euler: int
    closure: float


@dataclass
class GuestCageResult:
    guest_id: int
    cage: Optional[Cage]
    shell: Optional[GuestShell]
    assigned: str
    status: str
    n_local_nodes: int
    n_local_cycles: int
    n_local_rings: int


@dataclass
class CageAnalysisResult:
    frame: int
    cages: list[Cage]
    guest_results: list[GuestCageResult]
    shell_rows: list[tuple]
    counts: Counter
    n_guest: int
    n_cages: int
    n_local_cycles_total: int
    n_local_rings_total: int


def signature(ring_ids: tuple[int, ...], rings: list[GuestRing]) -> tuple[int, int, int]:
    n4 = 0
    n5 = 0
    n6 = 0

    for ring_id in ring_ids:
        size = rings[int(ring_id)].size

        if size == 4:
            n4 += 1
        elif size == 5:
            n5 += 1
        elif size == 6:
            n6 += 1

    return n4, n5, n6


def topology_from_edge_count(
    ring_ids: tuple[int, ...] | frozenset[int],
    rings: list[GuestRing],
    edge_count: dict[tuple[int, int], int],
) -> Optional[dict]:
    if not edge_count:
        return None

    nodes = set()

    for ring_id in ring_ids:
        nodes.update(rings[int(ring_id)].nodes)

    vertex_count = len(nodes)
    edge_count_len = len(edge_count)
    face_count = len(ring_ids)

    euler = vertex_count - edge_count_len + face_count

    total_face_edges = sum(edge_count.values())
    double_edges = sum(1 for count in edge_count.values() if count == 2)
    boundary_edges = sum(1 for count in edge_count.values() if count == 1)

    closure = 2.0 * double_edges / total_face_edges if total_face_edges else 0.0
    closed = all(count == 2 for count in edge_count.values())

    return {
        "nodes": tuple(sorted(int(node) for node in nodes)),
        "edges": tuple(sorted(edge_count.keys())),
        "euler": int(euler),
        "closure": float(closure),
        "closed": bool(closed),
        "boundary_edges": int(boundary_edges),
    }


def topology(
    ring_ids: tuple[int, ...] | range,
    rings: list[GuestRing],
) -> Optional[dict]:
    ring_id_tuple = tuple(int(ring_id) for ring_id in ring_ids)
    edge_count: dict[tuple[int, int], int] = defaultdict(int)

    for ring_id in ring_id_tuple:
        for edge in rings[ring_id].edges:
            edge_count[edge] += 1

    return topology_from_edge_count(ring_id_tuple, rings, edge_count)


def connected_ring_set(
    ring_ids: tuple[int, ...] | frozenset[int],
    rings: list[GuestRing],
) -> bool:
    ring_id_list = list(int(ring_id) for ring_id in ring_ids)

    if not ring_id_list:
        return False

    edge_to_rings: dict[tuple[int, int], list[int]] = defaultdict(list)

    for ring_id in ring_id_list:
        for edge in rings[ring_id].edges:
            edge_to_rings[edge].append(ring_id)

    adjacency = {ring_id: set() for ring_id in ring_id_list}

    for shared in edge_to_rings.values():
        if len(shared) < 2:
            continue

        for ring_a, ring_b in combinations(shared, 2):
            adjacency[ring_a].add(ring_b)
            adjacency[ring_b].add(ring_a)

    queue = deque([ring_id_list[0]])
    seen = {ring_id_list[0]}

    while queue:
        ring_id = queue.popleft()

        for neighbor in adjacency[ring_id]:
            if neighbor not in seen:
                seen.add(neighbor)
                queue.append(neighbor)

    return len(seen) == len(ring_id_list)


def build_ring_edge_index(
    rings: list[GuestRing],
) -> tuple[dict[tuple[int, int], set[int]], list[set[tuple[int, int]]]]:
    edge_to_rings: dict[tuple[int, int], set[int]] = defaultdict(set)
    ring_edge_sets: list[set[tuple[int, int]]] = []

    for ring_id, ring in enumerate(rings):
        edge_set = set(ring.edges)
        ring_edge_sets.append(edge_set)

        for edge in edge_set:
            edge_to_rings[edge].add(ring_id)

    return edge_to_rings, ring_edge_sets


def counts_add(counts: tuple[int, int, int], ring_size: int) -> tuple[int, int, int]:
    n4, n5, n6 = counts

    if ring_size == 4:
        return n4 + 1, n5, n6

    if ring_size == 5:
        return n4, n5 + 1, n6

    if ring_size == 6:
        return n4, n5, n6 + 1

    return counts


def counts_exceed(
    counts: tuple[int, int, int],
    target: tuple[int, int, int],
) -> bool:
    return counts[0] > target[0] or counts[1] > target[1] or counts[2] > target[2]


def target_face_number(target: tuple[int, int, int]) -> int:
    return target[0] + target[1] + target[2]


def nearest_cage_target(sig: tuple[int, int, int]) -> tuple[str, int]:
    best_name = "none"
    best_distance = 10**9

    for target, name in TARGETS:
        distance = (
            abs(sig[0] - target[0])
            + abs(sig[1] - target[1])
            + abs(sig[2] - target[2])
        )

        if distance < best_distance:
            best_distance = distance
            best_name = name

    return best_name, best_distance


def possible_targets(shell: GuestShell) -> list[tuple[tuple[int, int, int], str]]:
    candidates = []
    sig = (shell.n4, shell.n5, shell.n6)

    for target, cage_type in TARGETS:
        if sig[0] < target[0]:
            continue
        if sig[1] < target[1]:
            continue
        if sig[2] < target[2]:
            continue

        candidates.append((target, cage_type))

    candidates.sort(
        key=lambda item: (
            target_face_number(item[0]),
            abs(sig[0] - item[0][0])
            + abs(sig[1] - item[0][1])
            + abs(sig[2] - item[0][2]),
        )
    )

    return candidates


def grow_target_cage(
    rings: list[GuestRing],
    target: tuple[int, int, int],
    cage_type: str,
    params: CageParameters,
) -> Optional[tuple[tuple[int, ...], str, dict]]:
    if not rings:
        return None

    edge_to_rings, ring_edge_sets = build_ring_edge_index(rings)
    target_faces = target_face_number(target)

    states = []

    for ring_id, ring in enumerate(rings):
        counts = counts_add((0, 0, 0), ring.size)

        if counts_exceed(counts, target):
            continue

        edge_count = {edge: 1 for edge in ring_edge_sets[ring_id]}
        states.append((frozenset([ring_id]), edge_count, counts, ring.score))

    states.sort(key=lambda state: state[3], reverse=True)
    states = states[: params.beam_width]

    for _ in range(1, target_faces):
        new_states = []

        for selected, edge_count, counts, score in states:
            boundary = [edge for edge, count in edge_count.items() if count == 1]

            if not boundary:
                continue

            boundary_set = set(boundary)
            candidates = set()

            for edge in boundary:
                candidates.update(edge_to_rings[edge])

            candidates.difference_update(selected)

            scored_candidates = []

            for ring_id in candidates:
                shared = len(boundary_set & ring_edge_sets[ring_id])

                if shared == 0:
                    continue

                scored_candidates.append((-shared, -rings[ring_id].score, ring_id))

            scored_candidates.sort()
            scored_candidates = scored_candidates[: params.candidate_limit]

            for _, _, ring_id in scored_candidates:
                new_counts = counts_add(counts, rings[ring_id].size)

                if counts_exceed(new_counts, target):
                    continue

                new_edge_count = dict(edge_count)
                ok = True

                for edge in ring_edge_sets[ring_id]:
                    value = new_edge_count.get(edge, 0) + 1

                    if value > 2:
                        ok = False
                        break

                    new_edge_count[edge] = value

                if not ok:
                    continue

                selected_next = frozenset((*selected, ring_id))

                total_face_edges = sum(new_edge_count.values())
                double_edges = sum(1 for value in new_edge_count.values() if value == 2)
                closure = 2.0 * double_edges / total_face_edges if total_face_edges else 0.0

                new_score = score + rings[ring_id].score + 3.0 * closure
                new_states.append((selected_next, new_edge_count, new_counts, new_score))

        if not new_states:
            return None

        best_by_selected = {}

        for state in new_states:
            selected = state[0]

            if selected not in best_by_selected or state[3] > best_by_selected[selected][3]:
                best_by_selected[selected] = state

        states = sorted(best_by_selected.values(), key=lambda state: state[3], reverse=True)
        states = states[: params.beam_width]

    best = None

    for selected, edge_count, counts, score in states:
        if counts != target:
            continue

        topo = topology_from_edge_count(selected, rings, edge_count)

        if topo is None:
            continue

        if not topo["closed"]:
            continue

        if topo["euler"] != 2:
            continue

        if not connected_ring_set(selected, rings):
            continue

        final_score = score + 100.0 * topo["closure"]

        if best is None or final_score > best[0]:
            best = (final_score, selected, topo)

    if best is None:
        return None

    _, selected, topo = best

    return tuple(sorted(int(ring_id) for ring_id in selected)), cage_type, topo


def build_guest_shell(
    guest_id: int,
    guest_center: np.ndarray,
    rings: list[GuestRing],
    box: np.ndarray,
) -> Optional[GuestShell]:
    if not rings:
        return None

    local_ring_ids = tuple(range(len(rings)))
    topo = topology(local_ring_ids, rings)

    if topo is None:
        return None

    n4, n5, n6 = signature(local_ring_ids, rings)
    nearest_target, target_distance = nearest_cage_target((n4, n5, n6))

    return GuestShell(
        guest_id=int(guest_id),
        guest_center=tuple(float(value) for value in guest_center),
        ring_ids=tuple(int(ring.ring_id) for ring in rings),
        n4=int(n4),
        n5=int(n5),
        n6=int(n6),
        n_faces=len(rings),
        closure=float(topo["closure"]),
        boundary_edges=int(topo["boundary_edges"]),
        euler=int(topo["euler"]),
        connected=connected_ring_set(local_ring_ids, rings),
        coverage=float(estimate_directional_coverage(rings, guest_center, box)),
        nearest_target=nearest_target,
        target_distance=int(target_distance),
        nodes=topo["nodes"],
        edges=topo["edges"],
    )


def classify_partial_shell(shell: Optional[GuestShell], params: CageParameters) -> str:
    if shell is None:
        return "other"

    if shell.n_faces < params.partial_min_faces:
        return "other"

    if shell.closure < params.partial_min_closure:
        return "partial"

    if not shell.connected:
        return "partial"

    half_coverage = params.half_min_coverage <= shell.coverage <= params.half_max_coverage

    if (
        shell.n_faces >= params.half_min_faces
        and shell.n5 >= 6
        and shell.n6 == 0
        and half_coverage
    ):
        return "half_5^12"

    if (
        shell.n_faces >= params.half_min_faces
        and shell.n5 >= 6
        and 1 <= shell.n6 <= 2
        and half_coverage
    ):
        return "half_5^12_6^2"

    if (
        shell.n_faces >= params.half_min_faces
        and shell.n5 >= 6
        and 3 <= shell.n6 <= 4
        and half_coverage
    ):
        return "half_5^12_6^4"

    if 5 <= shell.n_faces <= 8 and shell.closure >= params.incipient_min_closure:
        return "incipient_cage"

    if shell.nearest_target == "5^12" and shell.target_distance <= 4 and shell.closure >= 0.55:
        return "partial_5^12"

    if shell.nearest_target == "5^12_6^2" and shell.target_distance <= 4 and shell.closure >= 0.55:
        return "partial_5^12_6^2"

    if shell.nearest_target == "5^12_6^4" and shell.target_distance <= 5 and shell.closure >= 0.55:
        return "partial_5^12_6^4"

    if shell.n_faces >= 8 and shell.boundary_edges >= params.open_min_boundary and shell.closure >= 0.35:
        return "open_cage"

    if shell.n_faces >= 8 and shell.closure >= 0.45:
        return "distorted_cage"

    return "partial"


def build_cage_from_topology(
    topo: dict,
    local_ring_ids: tuple[int, ...],
    rings: list[GuestRing],
    cage_type: str,
    guest_center: np.ndarray,
    guest_id: int,
    frame: int,
) -> Cage:
    global_ring_ids = tuple(int(rings[ring_id].ring_id) for ring_id in local_ring_ids)

    return Cage(
        nodes=topo["nodes"],
        edges=topo["edges"],
        rings=global_ring_ids,
        cage_type=cage_type,
        center=tuple(float(value) for value in guest_center),
        guest_id=int(guest_id),
        frame=int(frame),
        euler=int(topo["euler"]),
        closure=float(topo["closure"]),
    )


def build_partial_cage(
    shell: GuestShell,
    cage_type: str,
    guest_center: np.ndarray,
    guest_id: int,
    frame: int,
) -> Cage:
    return Cage(
        nodes=shell.nodes,
        edges=shell.edges,
        rings=shell.ring_ids,
        cage_type=cage_type,
        center=tuple(float(value) for value in guest_center),
        guest_id=int(guest_id),
        frame=int(frame),
        euler=int(shell.euler),
        closure=float(shell.closure),
    )


def analyze_guest_local(
    guest_id: int,
    guest_center: np.ndarray,
    frame: int,
    oxygen_pos: np.ndarray,
    box: np.ndarray,
    global_graph: NeighborGraph,
    candidate_mask: Optional[np.ndarray],
    params: CageParameters,
    local_nodes: Optional[np.ndarray] = None,
    ring_geometry_cache: Optional[dict[tuple[int, ...], RingRecord]] = None,
    local_ring_cache: Optional[
        dict[tuple[int, ...], tuple[list[RingRecord], int]]
    ] = None,
) -> GuestCageResult:
    if local_nodes is None:
        local_graph = build_local_graph_for_guest(
            guest_center=guest_center,
            oxygen_positions=oxygen_pos,
            box=box,
            global_graph=global_graph,
            radius=params.guest_radius,
            candidate_mask=candidate_mask,
        )
    else:
        nodes = np.asarray(local_nodes, dtype=np.int64)
        if candidate_mask is not None and len(nodes) > 0:
            nodes = nodes[candidate_mask[nodes]]
        local_graph = build_local_graph_from_nodes(global_graph, nodes)

    n_local_nodes = len(local_graph.global_nodes)
    local_graph = prune_local_graph_to_two_core(local_graph)

    if n_local_nodes < params.min_ring:
        return GuestCageResult(
            guest_id=guest_id,
            cage=None,
            shell=None,
            assigned="none",
            status="too_few_local_nodes",
            n_local_nodes=n_local_nodes,
            n_local_cycles=0,
            n_local_rings=0,
        )

    guest_rings, n_local_cycles, n_local_rings = build_guest_rings_from_local_graph(
        local_graph=local_graph,
        guest_center=guest_center,
        oxygen_pos=oxygen_pos,
        box=box,
        params=params,
        geometry_cache=ring_geometry_cache,
        local_ring_cache=local_ring_cache,
    )

    if n_local_cycles == 0:
        return GuestCageResult(
            guest_id=guest_id,
            cage=None,
            shell=None,
            assigned="none",
            status="no_cycle",
            n_local_nodes=n_local_nodes,
            n_local_cycles=n_local_cycles,
            n_local_rings=n_local_rings,
        )

    if n_local_rings == 0:
        return GuestCageResult(
            guest_id=guest_id,
            cage=None,
            shell=None,
            assigned="none",
            status="no_valid_ring",
            n_local_nodes=n_local_nodes,
            n_local_cycles=n_local_cycles,
            n_local_rings=n_local_rings,
        )

    if not guest_rings:
        return GuestCageResult(
            guest_id=guest_id,
            cage=None,
            shell=None,
            assigned="none",
            status="no_guest_facing_ring",
            n_local_nodes=n_local_nodes,
            n_local_cycles=n_local_cycles,
            n_local_rings=n_local_rings,
        )

    shell = build_guest_shell(
        guest_id=guest_id,
        guest_center=guest_center,
        rings=guest_rings,
        box=box,
    )

    if shell is None:
        return GuestCageResult(
            guest_id=guest_id,
            cage=None,
            shell=None,
            assigned="none",
            status="no_shell",
            n_local_nodes=n_local_nodes,
            n_local_cycles=n_local_cycles,
            n_local_rings=n_local_rings,
        )

    for target, cage_type in possible_targets(shell):
        result = grow_target_cage(
            rings=guest_rings,
            target=target,
            cage_type=cage_type,
            params=params,
        )

        if result is None:
            continue

        local_ring_ids, assigned_type, topo = result

        cage = build_cage_from_topology(
            topo=topo,
            local_ring_ids=local_ring_ids,
            rings=guest_rings,
            cage_type=assigned_type,
            guest_center=guest_center,
            guest_id=guest_id,
            frame=frame,
        )

        return GuestCageResult(
            guest_id=guest_id,
            cage=cage,
            shell=shell,
            assigned=assigned_type,
            status="complete",
            n_local_nodes=n_local_nodes,
            n_local_cycles=n_local_cycles,
            n_local_rings=n_local_rings,
        )

    if not params.standard_only:
        subtype = classify_partial_shell(shell, params)

        if subtype not in ("other", "none"):
            cage = build_partial_cage(
                shell=shell,
                cage_type=subtype,
                guest_center=guest_center,
                guest_id=guest_id,
                frame=frame,
            )

            return GuestCageResult(
                guest_id=guest_id,
                cage=cage,
                shell=shell,
                assigned=subtype,
                status="partial",
                n_local_nodes=n_local_nodes,
                n_local_cycles=n_local_cycles,
                n_local_rings=n_local_rings,
            )

    return GuestCageResult(
        guest_id=guest_id,
        cage=None,
        shell=shell,
        assigned="none",
        status="unassigned",
        n_local_nodes=n_local_nodes,
        n_local_cycles=n_local_cycles,
        n_local_rings=n_local_rings,
    )


def deduplicate_cages(cages: list[Cage], overlap_threshold: float = 0.85) -> list[Cage]:
    ordered = sorted(
        cages,
        key=lambda cage: (
            TYPE_PRIORITY.get(cage.cage_type, 0),
            float(cage.closure),
            len(cage.rings),
            len(cage.nodes),
        ),
        reverse=True,
    )
    kept: list[Cage] = []
    kept_nodes: list[set[int]] = []

    for cage in ordered:
        nodes = set(cage.nodes)
        duplicate = False

        for other_nodes in kept_nodes:
            union_size = len(nodes | other_nodes)
            overlap = len(nodes & other_nodes) / union_size if union_size else 1.0
            if overlap >= overlap_threshold:
                duplicate = True
                break

        if not duplicate:
            kept.append(cage)
            kept_nodes.append(nodes)

    return sorted(kept, key=lambda cage: (cage.guest_id, cage.cage_type))


def shell_row_from_guest_result(frame: int, result: GuestCageResult) -> tuple:
    shell = result.shell

    if shell is None:
        return (
            frame,
            result.guest_id,
            0,
            0,
            0,
            0,
            0.0,
            0,
            0,
            0,
            0.0,
            "none",
            999,
            result.assigned,
            result.status,
            result.n_local_nodes,
            result.n_local_cycles,
            result.n_local_rings,
        )

    return (
        frame,
        result.guest_id,
        shell.n4,
        shell.n5,
        shell.n6,
        shell.n_faces,
        shell.closure,
        shell.boundary_edges,
        shell.euler,
        int(shell.connected),
        shell.coverage,
        shell.nearest_target,
        shell.target_distance,
        result.assigned,
        result.status,
        result.n_local_nodes,
        result.n_local_cycles,
        result.n_local_rings,
    )


def analyze_cages_for_frame(
    frame: int,
    oxygen_pos: np.ndarray,
    guest_pos: Optional[np.ndarray],
    box: np.ndarray,
    global_graph: NeighborGraph,
    candidate_mask: Optional[np.ndarray],
    params: CageParameters,
    quiet: bool = False,
) -> CageAnalysisResult:
    if guest_pos is None or len(guest_pos) == 0:
        return CageAnalysisResult(
            frame=int(frame),
            cages=[],
            guest_results=[],
            shell_rows=[],
            counts=Counter(),
            n_guest=0,
            n_cages=0,
            n_local_cycles_total=0,
            n_local_rings_total=0,
        )

    guest_results: list[GuestCageResult] = []
    ring_geometry_cache: dict[tuple[int, ...], RingRecord] = {}
    local_ring_cache: dict[tuple[int, ...], tuple[list[RingRecord], int]] = {}
    local_nodes_by_guest = select_nodes_within_radius(
        centers=guest_pos,
        positions=oxygen_pos,
        box=box,
        radius=params.guest_radius,
    )

    for guest_id, guest_center in enumerate(guest_pos):
        result = analyze_guest_local(
            guest_id=int(guest_id),
            guest_center=np.asarray(guest_center, dtype=np.float64),
            frame=int(frame),
            oxygen_pos=oxygen_pos,
            box=box,
            global_graph=global_graph,
            candidate_mask=candidate_mask,
            params=params,
            local_nodes=local_nodes_by_guest[guest_id],
            ring_geometry_cache=ring_geometry_cache,
            local_ring_cache=local_ring_cache,
        )

        guest_results.append(result)

        if not quiet:
            print_guest_result(result)

    cages = [result.cage for result in guest_results if result.cage is not None]
    cages = deduplicate_cages(cages, params.dedup_water_overlap)

    counts = Counter(cage.cage_type for cage in cages)
    shell_rows = [shell_row_from_guest_result(int(frame), result) for result in guest_results]

    n_local_cycles_total = sum(result.n_local_cycles for result in guest_results)
    n_local_rings_total = sum(result.n_local_rings for result in guest_results)

    return CageAnalysisResult(
        frame=int(frame),
        cages=cages,
        guest_results=guest_results,
        shell_rows=shell_rows,
        counts=counts,
        n_guest=len(guest_pos),
        n_cages=len(cages),
        n_local_cycles_total=int(n_local_cycles_total),
        n_local_rings_total=int(n_local_rings_total),
    )


def cage_counts_row(result: CageAnalysisResult) -> dict:
    row = {cage_type: int(result.counts.get(cage_type, 0)) for cage_type in CAGE_TYPES}
    row["total"] = int(result.n_cages)
    return row


def print_guest_result(result: GuestCageResult) -> None:
    if result.shell is None:
        print(
            f"    guest {result.guest_id:5d}: "
            f"local_nodes={result.n_local_nodes:4d} "
            f"cycles={result.n_local_cycles:5d} "
            f"rings={result.n_local_rings:4d} "
            f"assigned={result.assigned} "
            f"status={result.status}",
            flush=True,
        )
        return

    shell = result.shell

    print(
        f"    guest {result.guest_id:5d}: "
        f"local_nodes={result.n_local_nodes:4d} "
        f"cycles={result.n_local_cycles:5d} "
        f"rings={result.n_local_rings:4d} "
        f"sig=({shell.n4},{shell.n5},{shell.n6}) "
        f"closure={shell.closure:.3f} "
        f"coverage={shell.coverage:.3f} "
        f"assigned={result.assigned} "
        f"status={result.status}",
        flush=True,
    )


def print_cage_progress(result: CageAnalysisResult) -> None:
    print(
        f"[frame {result.frame}] "
        f"cages={result.n_cages} "
        f"{dict(result.counts)} "
        f"local_cycles={result.n_local_cycles_total} "
        f"local_rings={result.n_local_rings_total}",
        flush=True,
    )
