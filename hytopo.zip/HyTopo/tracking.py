from __future__ import annotations

import os
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

import numpy as np


@dataclass(frozen=True)
class TrackingParameters:
    enabled: bool = True
    gap_tolerance: int = 1
    min_water_overlap: float = 0.50
    min_same_guest_overlap: float = 0.25
    dedup_water_overlap: float = 0.85
    occupancy_radius: float = 4.5
    occupancy_center: str = "cage"
    write_lifetime: bool = True
    write_transitions: bool = True
    write_occupancy: bool = True
    lifetime_name: str = "cage_lifetime.dat"
    transitions_name: str = "cage_transitions.dat"
    occupancy_name: str = "cage_occupancy.dat"


@dataclass(frozen=True)
class CageEvent:
    frame_index: int
    time: float
    guest_id: int
    cage_type: str
    water_ids: tuple[int, ...]
    score: float = 0.0
    center: Optional[tuple[float, float, float]] = None
    occupancy_count: int = -1
    occupancy: str = "unknown"
    raw_index: int = -1
    status: str = "complete"

    @property
    def water_key(self) -> frozenset[int]:
        return frozenset(self.water_ids)


@dataclass
class CageTransition:
    track_id: int
    guest_id: int
    frame_index: int
    time: float
    from_type: str
    to_type: str


@dataclass
class CageTrack:
    track_id: int
    guest_id: int
    start_frame: int
    end_frame: int
    start_time: float
    end_time: float
    last_frame: int
    last_time: float
    last_type: str
    last_water_ids: tuple[int, ...]
    last_score: float
    n_observed: int = 1
    n_missing: int = 0
    type_counts: Counter = field(default_factory=Counter)
    occupancy_counts: Counter = field(default_factory=Counter)
    transitions: list[CageTransition] = field(default_factory=list)
    events: list[CageEvent] = field(default_factory=list)
    active: bool = True
    end_reason: str = "active"

    def update(self, event: CageEvent, transition: Optional[CageTransition]) -> None:
        self.end_frame = event.frame_index
        self.end_time = event.time
        self.last_frame = event.frame_index
        self.last_time = event.time
        self.last_type = event.cage_type
        self.last_water_ids = event.water_ids
        self.last_score = event.score
        self.n_observed += 1
        self.n_missing = 0
        self.type_counts[event.cage_type] += 1
        self.occupancy_counts[event.occupancy] += 1
        self.events.append(event)

        if transition is not None:
            self.transitions.append(transition)

    @property
    def dominant_type(self) -> str:
        if not self.type_counts:
            return self.last_type
        return self.type_counts.most_common(1)[0][0]

    @property
    def dominant_occupancy(self) -> str:
        if not self.occupancy_counts:
            return "unknown"
        return self.occupancy_counts.most_common(1)[0][0]

    @property
    def lifetime_frames(self) -> int:
        return self.end_frame - self.start_frame + 1

    @property
    def lifetime_time(self) -> float:
        return self.end_time - self.start_time


class CageTracker:
    def __init__(self, params: Optional[TrackingParameters] = None) -> None:
        self.params = params if params is not None else TrackingParameters()
        self.tracks: list[CageTrack] = []
        self.active_track_ids: set[int] = set()
        self.transitions: list[CageTransition] = []
        self.occupancy_events: list[CageEvent] = []
        self.frame_events: dict[int, list[CageEvent]] = {}
        self._next_track_id = 1

    def update(
        self,
        frame_index: int,
        time: float,
        cages: Any,
        guest_positions: Optional[np.ndarray] = None,
        oxygen_positions: Optional[np.ndarray] = None,
        box: Optional[np.ndarray] = None,
    ) -> list[CageEvent]:
        records = flatten_cage_records(cages)

        events = build_cage_events(
            frame_index=frame_index,
            time=time,
            records=records,
            guest_positions=guest_positions,
            oxygen_positions=oxygen_positions,
            box=box,
            params=self.params,
        )

        events = deduplicate_cage_events(events, self.params)

        self.frame_events[frame_index] = events
        self.occupancy_events.extend(events)

        unmatched_track_ids = set(self.active_track_ids)

        for event in events:
            track = self._match_track(event, unmatched_track_ids)

            if track is None:
                self._start_track(event)
                continue

            transition = None

            if track.last_type != event.cage_type:
                transition = CageTransition(
                    track_id=track.track_id,
                    guest_id=track.guest_id,
                    frame_index=event.frame_index,
                    time=event.time,
                    from_type=track.last_type,
                    to_type=event.cage_type,
                )
                self.transitions.append(transition)

            track.update(event, transition)
            unmatched_track_ids.discard(track.track_id)

        self._age_unmatched_tracks(unmatched_track_ids)
        return events

    def finalize(self) -> None:
        for track_id in list(self.active_track_ids):
            track = self.tracks[track_id - 1]
            track.active = False
            track.end_reason = "trajectory_end"

        self.active_track_ids.clear()

    def write_outputs(self, outdir: str) -> None:
        os.makedirs(outdir, exist_ok=True)

        if self.params.write_lifetime:
            write_lifetime_table(
                os.path.join(outdir, self.params.lifetime_name),
                self.lifetime_rows(),
            )

        if self.params.write_transitions:
            write_transition_table(
                os.path.join(outdir, self.params.transitions_name),
                self.transition_rows(),
                self.transition_summary_rows(),
            )

        if self.params.write_occupancy:
            write_occupancy_table(
                os.path.join(outdir, self.params.occupancy_name),
                self.occupancy_rows(),
            )

    def lifetime_rows(self) -> list[dict[str, Any]]:
        rows = []

        for track in self.tracks:
            rows.append(
                {
                    "track_id": track.track_id,
                    "guest_id": track.guest_id,
                    "start_frame": track.start_frame,
                    "end_frame": track.end_frame,
                    "start_time": track.start_time,
                    "end_time": track.end_time,
                    "lifetime_frames": track.lifetime_frames,
                    "lifetime_time": track.lifetime_time,
                    "n_observed": track.n_observed,
                    "dominant_type": track.dominant_type,
                    "last_type": track.last_type,
                    "dominant_occupancy": track.dominant_occupancy,
                    "n_transitions": len(track.transitions),
                    "end_reason": track.end_reason,
                }
            )

        return rows

    def transition_rows(self) -> list[dict[str, Any]]:
        return [
            {
                "track_id": item.track_id,
                "guest_id": item.guest_id,
                "frame_index": item.frame_index,
                "time": item.time,
                "from_type": item.from_type,
                "to_type": item.to_type,
            }
            for item in self.transitions
        ]

    def transition_summary_rows(self) -> list[dict[str, Any]]:
        counter = Counter((item.from_type, item.to_type) for item in self.transitions)

        return [
            {
                "from_type": from_type,
                "to_type": to_type,
                "count": count,
            }
            for (from_type, to_type), count in sorted(counter.items())
        ]

    def occupancy_rows(self) -> list[dict[str, Any]]:
        rows = []

        for event in self.occupancy_events:
            rows.append(
                {
                    "frame_index": event.frame_index,
                    "time": event.time,
                    "guest_id": event.guest_id,
                    "cage_type": event.cage_type,
                    "occupancy": event.occupancy,
                    "occupancy_count": event.occupancy_count,
                    "n_waters": len(event.water_ids),
                    "score": event.score,
                    "status": event.status,
                }
            )

        return rows

    def _start_track(self, event: CageEvent) -> CageTrack:
        track = CageTrack(
            track_id=self._next_track_id,
            guest_id=event.guest_id,
            start_frame=event.frame_index,
            end_frame=event.frame_index,
            start_time=event.time,
            end_time=event.time,
            last_frame=event.frame_index,
            last_time=event.time,
            last_type=event.cage_type,
            last_water_ids=event.water_ids,
            last_score=event.score,
            type_counts=Counter({event.cage_type: 1}),
            occupancy_counts=Counter({event.occupancy: 1}),
            events=[event],
        )

        self.tracks.append(track)
        self.active_track_ids.add(track.track_id)
        self._next_track_id += 1
        return track

    def _match_track(
        self,
        event: CageEvent,
        candidate_track_ids: set[int],
    ) -> Optional[CageTrack]:
        best_track = None
        best_score = -1.0

        for track_id in candidate_track_ids:
            track = self.tracks[track_id - 1]

            if not track.active:
                continue

            if event.frame_index - track.last_frame > self.params.gap_tolerance + 1:
                continue

            score = track_match_score(event, track)

            if score > best_score:
                best_score = score
                best_track = track

        if best_track is None:
            return None

        if best_track.guest_id == event.guest_id and best_score >= self.params.min_same_guest_overlap:
            return best_track

        if best_score >= self.params.min_water_overlap:
            return best_track

        return None

    def _age_unmatched_tracks(self, unmatched_track_ids: set[int]) -> None:
        for track_id in unmatched_track_ids:
            track = self.tracks[track_id - 1]
            track.n_missing += 1

            if track.n_missing > self.params.gap_tolerance:
                track.active = False
                track.end_reason = "disappeared"
                self.active_track_ids.discard(track_id)


def build_cage_events(
    frame_index: int,
    time: float,
    records: Iterable[Any],
    guest_positions: Optional[np.ndarray],
    oxygen_positions: Optional[np.ndarray],
    box: Optional[np.ndarray],
    params: TrackingParameters,
) -> list[CageEvent]:
    events = []

    for raw_index, record in enumerate(records):
        guest_id = int(get_first_attr(record, ("guest_id", "guest_index", "guest", "center_guest"), -1))
        cage_type = str(get_first_attr(record, ("cage_type", "type", "name", "label"), "other"))
        water_ids = canonical_water_ids(get_first_attr(record, ("water_ids", "waters", "oxygen_ids", "nodes"), ()))
        score = float(get_first_attr(record, ("score", "quality", "confidence"), 0.0))
        status = str(get_first_attr(record, ("status", "state"), "complete"))

        center = get_event_center(record, water_ids, oxygen_positions, params)
        occupancy_count = estimate_occupancy_count(
            center,
            guest_positions,
            params.occupancy_radius,
            box=box,
        )
        occupancy = classify_occupancy(occupancy_count)

        if guest_id >= 0 and occupancy_count < 0:
            occupancy_count = 1
            occupancy = "single"

        events.append(
            CageEvent(
                frame_index=frame_index,
                time=time,
                guest_id=guest_id,
                cage_type=cage_type,
                water_ids=water_ids,
                score=score,
                center=center,
                occupancy_count=occupancy_count,
                occupancy=occupancy,
                raw_index=raw_index,
                status=status,
            )
        )

    return events


def deduplicate_cage_events(
    events: list[CageEvent],
    params: TrackingParameters,
) -> list[CageEvent]:
    grouped: dict[int, list[CageEvent]] = defaultdict(list)

    for event in events:
        grouped[event.guest_id].append(event)

    kept = []

    for guest_events in grouped.values():
        ordered = sorted(
            guest_events,
            key=lambda item: (type_priority(item.cage_type), item.score, len(item.water_ids)),
            reverse=True,
        )
        selected: list[CageEvent] = []

        for event in ordered:
            duplicate = False

            for other in selected:
                if event.water_key == other.water_key:
                    duplicate = True
                    break

                if event.cage_type == other.cage_type:
                    overlap = jaccard(event.water_key, other.water_key)

                    if overlap >= params.dedup_water_overlap:
                        duplicate = True
                        break

            if not duplicate:
                selected.append(event)

        kept.extend(selected)

    kept.sort(key=lambda item: (item.frame_index, item.guest_id, item.raw_index))
    return kept


def track_match_score(event: CageEvent, track: CageTrack) -> float:
    water_overlap = jaccard(event.water_key, frozenset(track.last_water_ids))
    same_guest_bonus = 0.35 if event.guest_id == track.guest_id and event.guest_id >= 0 else 0.0
    same_type_bonus = 0.15 if event.cage_type == track.last_type else 0.0
    gap_penalty = max(0, event.frame_index - track.last_frame - 1) * 0.05

    return water_overlap + same_guest_bonus + same_type_bonus - gap_penalty


def flatten_cage_records(result: Any) -> list[Any]:
    if result is None:
        return []

    if isinstance(result, list):
        return result

    if isinstance(result, tuple):
        return list(result)

    records = []

    for name in (
        "cages",
        "records",
        "cage_records",
        "detected_cages",
        "complete_cages",
        "partial_cages",
        "open_cages",
        "distorted_cages",
    ):
        value = get_attr(result, name)

        if value is None:
            continue

        if isinstance(value, list):
            records.extend(value)
        elif isinstance(value, tuple):
            records.extend(value)

    if records:
        return records

    if isinstance(result, dict):
        for key in ("cages", "records", "cage_records"):
            value = result.get(key)

            if isinstance(value, list):
                return value

            if isinstance(value, tuple):
                return list(value)

    return []


def get_event_center(
    record: Any,
    water_ids: tuple[int, ...],
    oxygen_positions: Optional[np.ndarray],
    params: TrackingParameters,
) -> Optional[tuple[float, float, float]]:
    center = get_first_attr(record, ("center", "cage_center", "position"), None)

    if center is not None:
        return tuple(float(value) for value in center)

    if oxygen_positions is None:
        return None

    if params.occupancy_center != "water":
        return None

    if not water_ids:
        return None

    valid_ids = [idx for idx in water_ids if 0 <= idx < len(oxygen_positions)]

    if not valid_ids:
        return None

    coords = oxygen_positions[np.asarray(valid_ids, dtype=np.int64)]
    mean = np.mean(coords, axis=0)
    return tuple(float(value) for value in mean)


def estimate_occupancy_count(
    center: Optional[tuple[float, float, float]],
    guest_positions: Optional[np.ndarray],
    radius: float,
    box: Optional[np.ndarray] = None,
) -> int:
    if center is None or guest_positions is None:
        return -1

    if len(guest_positions) == 0:
        return 0

    center_array = np.asarray(center, dtype=np.float64)
    delta = guest_positions - center_array
    if box is not None:
        delta = minimum_image_deltas(delta, box)
    distances = np.sqrt(np.sum(delta * delta, axis=1))

    return int(np.count_nonzero(distances <= radius))


def minimum_image_deltas(delta: np.ndarray, box: np.ndarray) -> np.ndarray:
    delta = np.asarray(delta, dtype=np.float64)
    dimensions = np.asarray(box, dtype=np.float64)

    if dimensions.size < 3 or np.any(dimensions[:3] <= 0.0):
        return delta

    if dimensions.size < 6 or np.allclose(dimensions[3:6], 90.0):
        lengths = dimensions[:3]
        return delta - lengths * np.rint(delta / lengths)

    a, b, c = dimensions[:3]
    alpha, beta, gamma = np.deg2rad(dimensions[3:6])
    sin_gamma = np.sin(gamma)
    if abs(sin_gamma) < 1.0e-12:
        return delta

    cell = np.asarray(
        [
            [a, 0.0, 0.0],
            [b * np.cos(gamma), b * sin_gamma, 0.0],
            [
                c * np.cos(beta),
                c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / sin_gamma,
                0.0,
            ],
        ],
        dtype=np.float64,
    )
    z_sq = c * c - cell[2, 0] ** 2 - cell[2, 1] ** 2
    cell[2, 2] = np.sqrt(max(0.0, z_sq))

    try:
        fractional = delta @ np.linalg.inv(cell)
    except np.linalg.LinAlgError:
        return delta

    fractional -= np.rint(fractional)
    return fractional @ cell


def classify_occupancy(count: int) -> str:
    if count < 0:
        return "unknown"

    if count == 0:
        return "empty"

    if count == 1:
        return "single"

    return "multiple"


def canonical_water_ids(value: Any) -> tuple[int, ...]:
    if value is None:
        return ()

    if isinstance(value, np.ndarray):
        values = value.tolist()
    else:
        values = list(value)

    return tuple(sorted({int(item) for item in values}))


def jaccard(left: frozenset[int], right: frozenset[int]) -> float:
    if not left and not right:
        return 1.0

    if not left or not right:
        return 0.0

    union = len(left | right)

    if union == 0:
        return 0.0

    return len(left & right) / union


def get_attr(obj: Any, name: str) -> Any:
    if isinstance(obj, dict):
        return obj.get(name)

    return getattr(obj, name, None)


def get_first_attr(obj: Any, names: tuple[str, ...], default: Any) -> Any:
    for name in names:
        value = get_attr(obj, name)

        if value is not None:
            return value

    return default


def type_priority(cage_type: str) -> int:
    priorities = {
        "5^12": 100,
        "5^12_6^2": 95,
        "5^12_6^3": 92,
        "5^12_6^4": 90,
        "4^3_5^6_6^3": 88,
        "5^12_6^8": 85,
        "half_5^12": 55,
        "half_5^12_6^2": 54,
        "half_5^12_6^4": 53,
        "incipient_cage": 45,
        "open_cage": 40,
        "distorted_cage": 35,
        "partial_5^12": 30,
        "partial_5^12_6^2": 28,
        "partial_5^12_6^4": 26,
        "partial": 20,
        "other": 0,
    }

    return priorities.get(cage_type, 0)


def write_lifetime_table(path: str, rows: list[dict[str, Any]]) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(
            "track_id guest_id start_frame end_frame start_time end_time "
            "lifetime_frames lifetime_time n_observed dominant_type last_type "
            "dominant_occupancy n_transitions end_reason\n"
        )

        for row in rows:
            handle.write(
                f"{row['track_id']} {row['guest_id']} "
                f"{row['start_frame']} {row['end_frame']} "
                f"{row['start_time']:.6f} {row['end_time']:.6f} "
                f"{row['lifetime_frames']} {row['lifetime_time']:.6f} "
                f"{row['n_observed']} {row['dominant_type']} {row['last_type']} "
                f"{row['dominant_occupancy']} {row['n_transitions']} "
                f"{row['end_reason']}\n"
            )


def write_transition_table(
    path: str,
    rows: list[dict[str, Any]],
    summary_rows: list[dict[str, Any]],
) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("transitions\n")
        handle.write("track_id guest_id frame_index time from_type to_type\n")

        for row in rows:
            handle.write(
                f"{row['track_id']} {row['guest_id']} "
                f"{row['frame_index']} {row['time']:.6f} "
                f"{row['from_type']} {row['to_type']}\n"
            )

        handle.write("summary\n")
        handle.write("from_type to_type count\n")

        for row in summary_rows:
            handle.write(f"{row['from_type']} {row['to_type']} {row['count']}\n")


def write_occupancy_table(path: str, rows: list[dict[str, Any]]) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(
            "frame_index time guest_id cage_type occupancy occupancy_count "
            "n_waters score status\n"
        )

        for row in rows:
            handle.write(
                f"{row['frame_index']} {row['time']:.6f} "
                f"{row['guest_id']} {row['cage_type']} "
                f"{row['occupancy']} {row['occupancy_count']} "
                f"{row['n_waters']} {row['score']:.6f} {row['status']}\n"
            )
