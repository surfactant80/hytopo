from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np

from .cli import build_parser, make_config
from .config import CAGE_TYPES
from .nucleation import (
    NucleationParameters,
    NucleationPoint,
    analyze_nucleation,
    read_nmax_hyd_from_timeseries,
)
from .tracking import CageTracker, TrackingParameters, estimate_occupancy_count
from .network import TransitionNetwork
from .extxyz import ExtXYZReader, select_extxyz_atoms
from .phase import PHASE_SH, PHASE_SI, PHASE_SII, PhaseParameters, classify_phase


class ConfigurationTests(unittest.TestCase):
    def test_skip_hop_cage_mode_is_valid(self) -> None:
        parser = build_parser()
        args = parser.parse_args(
            [
                "-top",
                "system.gro",
                "-guest",
                "resname CH4",
                "--find-cages",
                "--skip-hop",
                "--no-numba",
                "--no-plots",
            ]
        )
        config = make_config(args)
        config.validate()

        self.assertFalse(config.run_hop)
        self.assertEqual(config.cage.ring_backend, "python")
        self.assertFalse(config.output.make_plots)

    def test_partial_types_are_reportable(self) -> None:
        self.assertIn("partial_5^12", CAGE_TYPES)
        self.assertIn("partial_5^12_6^2", CAGE_TYPES)
        self.assertIn("partial_5^12_6^4", CAGE_TYPES)


class NucleationTests(unittest.TestCase):
    def test_new_and_legacy_timeseries_are_read_correctly(self) -> None:
        cases = (
            (
                "Frame Time(ps) H_total H_crys H_pre Hyd_order Ice O_total "
                "Delta Nmax_hyd Nmax_ice\n"
                "10 2.5 0 0 0 0 0 0 0 51.7 4\n",
                10,
            ),
            (
                "Time(ps) H_total H_crys H_pre Hyd_order Ice O_total "
                "Delta Nmax_hyd Nmax_ice\n"
                "2.5 0 0 0 0 0 0 0 51.7 4\n",
                0,
            ),
        )

        for content, expected_frame in cases:
            with self.subTest(expected_frame=expected_frame):
                with tempfile.TemporaryDirectory() as directory:
                    path = Path(directory) / "timeseries.dat"
                    path.write_text(content, encoding="utf-8")
                    points = read_nmax_hyd_from_timeseries(str(path))

                self.assertEqual(len(points), 1)
                self.assertEqual(points[0].frame_index, expected_frame)
                self.assertEqual(points[0].nmax_hyd, 52)

    def test_allowed_gap_persistence(self) -> None:
        points = [
            NucleationPoint(index, float(index), value)
            for index, value in enumerate((50, 49, 51, 52))
        ]
        result = analyze_nucleation(
            points,
            NucleationParameters(
                method="fixed",
                min_cluster_size=50,
                persist_frames=3,
                allow_gaps=1,
            ),
        )
        self.assertTrue(result.nucleated)
        self.assertEqual(result.nucleation_frame, 0)

    def test_adaptive_commitment_uses_liquid_baseline_and_growth(self) -> None:
        points = [
            NucleationPoint(index, float(index), value)
            for index, value in enumerate((2, 3, 2, 10, 12, 16))
        ]
        result = analyze_nucleation(
            points,
            NucleationParameters(
                method="commitment",
                persist_frames=3,
                baseline_frames=3,
                baseline_sigma=3.0,
                adaptive_min_size=5,
                commitment_min_growth=5.0,
            ),
        )
        self.assertTrue(result.nucleated)
        self.assertEqual(result.nucleation_frame, 3)
        self.assertEqual(result.effective_threshold, 5)


class TrackingTests(unittest.TestCase):
    def test_occupancy_uses_periodic_boundary(self) -> None:
        count = estimate_occupancy_count(
            center=(0.2, 0.0, 0.0),
            guest_positions=np.asarray([[9.8, 0.0, 0.0]]),
            radius=1.0,
            box=np.asarray([10.0, 10.0, 10.0, 90.0, 90.0, 90.0]),
        )
        self.assertEqual(count, 1)

    def test_trajectory_end_is_not_counted_as_dissociation(self) -> None:
        params = TrackingParameters(gap_tolerance=0)

        surviving = CageTracker(params)
        surviving.update(
            0,
            0.0,
            [{"guest_id": 0, "cage_type": "5^12", "nodes": (1, 2, 3, 4)}],
        )
        surviving.finalize()
        network = TransitionNetwork(".")
        network.build_from_tracker(surviving)
        self.assertNotIn(("5^12", "Liquid"), network.transitions)

        disappeared = CageTracker(params)
        disappeared.update(
            0,
            0.0,
            [{"guest_id": 0, "cage_type": "5^12", "nodes": (1, 2, 3, 4)}],
        )
        disappeared.update(1, 1.0, [])
        disappeared.finalize()
        network = TransitionNetwork(".")
        network.build_from_tracker(disappeared)
        self.assertEqual(network.transitions[("5^12", "Liquid")], 1)


class ExtXYZTests(unittest.TestCase):
    def test_periodic_extended_xyz_is_indexed_and_read(self) -> None:
        content = (
            "2\n"
            'time=1.5 pbc="T T T" '
            'Lattice="20 0 0 0 20 0 0 0 20" '
            "Properties=species:S:1:pos:R:3:force:R:3\n"
            "O 1 2 3 0 0 0\n"
            "C 4 5 6 0 0 0\n"
            "2\n"
            'time=2.5 pbc="T T T" '
            'Lattice="21 0 0 0 22 0 0 0 23" '
            "Properties=species:S:1:pos:R:3\n"
            "O 2 3 4\n"
            "C 5 6 7\n"
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.etxyz"
            path.write_text(content, encoding="utf-8")
            reader = ExtXYZReader(str(path))
            frame = reader.read(1)

        self.assertEqual(len(reader), 2)
        self.assertEqual(frame.symbols, ("O", "C"))
        np.testing.assert_allclose(frame.box[:3], (21.0, 22.0, 23.0))
        np.testing.assert_allclose(frame.positions[1], (5.0, 6.0, 7.0))
        self.assertEqual(frame.time_ps, 2.5)
        oxygen = select_extxyz_atoms(
            "(resname SOL) and (name OW)",
            frame.symbols,
            oxygen_fallback=True,
        )
        np.testing.assert_array_equal(oxygen, (0,))


class PhaseTests(unittest.TestCase):
    class _Cage:
        def __init__(self, cage_type: str):
            self.cage_type = cage_type

    def _classify(self, counts: dict[str, int]):
        cages = [
            self._Cage(cage_type)
            for cage_type, count in counts.items()
            for _ in range(count)
        ]
        return classify_phase(
            0,
            0.0,
            cages,
            PhaseParameters(min_complete_cages=4, min_confidence=0.4),
        )

    def test_standard_phase_compositions(self) -> None:
        self.assertEqual(
            self._classify({"5^12": 2, "5^12_6^2": 6}).phase,
            PHASE_SI,
        )
        self.assertEqual(
            self._classify({"5^12": 16, "5^12_6^4": 8}).phase,
            PHASE_SII,
        )
        self.assertEqual(
            self._classify(
                {
                    "5^12": 3,
                    "4^3_5^6_6^3": 2,
                    "5^12_6^8": 1,
                }
            ).phase,
            PHASE_SH,
        )


if __name__ == "__main__":
    unittest.main()
